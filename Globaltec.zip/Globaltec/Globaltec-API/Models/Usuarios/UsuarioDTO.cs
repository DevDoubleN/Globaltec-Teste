﻿using Globaltec_API.Models.Pessoas;

namespace Globaltec_API.Models.Usuarios
{
    public class UsuarioDTO
    {
        public string Login { get; set; }

        public string Senha { get; set; }

        public int PessoaCodigo { get; set; }
    }
}
