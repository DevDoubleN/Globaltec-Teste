﻿namespace Globaltec_API.Models.Pessoas
{
    public class PessoaDTO
    {
        public string Nome { get; set; }

        public string Cpf { get; set; }

        public string Uf { get; set; }

        public DateTime DataNascimento { get; set; }
    }
}
