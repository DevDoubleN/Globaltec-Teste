﻿using Globaltec_API.Configurations;
using Globaltec_API.Entities;
using Globaltec_API.Models.Usuarios;
using Microsoft.AspNetCore.Mvc;

namespace Globaltec_API.Controllers
{
    [Route("api/Usuario")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        #region Membros

        private readonly GlobaltecDbContext _globaltecDbContext;
        private readonly IAuthenticationService _authenticationService;

        #endregion

        #region Construtor

        public UsuarioController(GlobaltecDbContext globaltecDbContext, IAuthenticationService authenticationService)
        {
            _globaltecDbContext = globaltecDbContext;
            _authenticationService = authenticationService;
        }

        #endregion

        #region Actions

        /// <summary>
        /// Busca o cadastro de um Usuário de acordo com o seu Código
        /// </summary>
        /// <param name="id">Código do Usuário</param>
        /// <returns>Cadastro do Usuário</returns>
        /// <response code="200">Sucesso!</response>
        /// <response code="401">Não Autorizado!</response>
        /// <response code="404">Não Encontrado!</response>
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var usuario = _globaltecDbContext.Usuarios.FirstOrDefault(u => u.Codigo == id);
            if (usuario == null)
                return NotFound();

            return Ok(usuario);
        }

        /// <summary>
        /// Autenticar um usuário
        /// </summary>
        /// <param name="usuarioDTO">Dados de Login</param>
        /// <returns>Retorna um Status OK com dados do Usuário e do Token em caso de sucesso.</returns>
        /// <response code="200">Sucesso!</response>
        /// <response code="404">Não Encontrado!</response>
        [HttpPost("Login")]
        public IActionResult Login(LoginDTO loginDTO)
        {
            var usuario = _globaltecDbContext.Usuarios.FirstOrDefault(u => u.Login == loginDTO.Login &&
                                                                        u.Senha == loginDTO.Senha);

            if (usuario == null)
                return NotFound();

            var usuarioOutput = new UsuarioOutput()
            {
                Codigo = usuario.Codigo,
                Login = loginDTO.Login
            };

            var token = _authenticationService.GerarToken(usuarioOutput);

            return Ok(new
            {
                Token = token,
                Usuario = usuarioOutput
            });
        }

        /// <summary>
        /// Cadastrar um novo Usuário.
        /// </summary>
        /// <param name="usuarioDTO">Dados do Usuário</param>
        /// <returns>Cadastro criado.</returns>
        /// <response code="200">Sucesso</response>
        /// <response code="201">Sucesso</response>
        /// <response code="400">Erro de informações</response>
        [HttpPost("New")]
        public IActionResult Post(UsuarioDTO usuarioDTO)
        {
            var getUsuario = _globaltecDbContext.Usuarios.OrderByDescending(u => u.Codigo).Take(1).FirstOrDefault();

            var usuario = new Usuario(
                getUsuario == null ? 1 : getUsuario.Codigo +1,
                usuarioDTO.Login,
                usuarioDTO.Senha,
                usuarioDTO.PessoaCodigo);

            _globaltecDbContext.Usuarios.Add(usuario);

            return CreatedAtAction("GetById", new { id = usuario.Codigo }, usuario);
        }

        /// <summary>
        /// Atualizar o cadastro de um Usuário.
        /// </summary>
        /// <param name="id">Identificador do Usuário</param>
        /// <param name="usuarioDTO">Novos dados para o cadastro selecionado.</param>
        /// <returns>Cadastro atualizado</returns>
        /// <response code="204">Sucesso!</response>
        /// <response code="404">Não encontrado!</response>
        [HttpPut("Update")]
        public IActionResult Put(int id, UsuarioDTO usuarioDTO)
        {
            var usuario = _globaltecDbContext.Usuarios.FirstOrDefault(u => u.Codigo == id);

            if (usuario == null)
                return NotFound();

            usuario.Update(usuarioDTO.Login, usuarioDTO.Senha);

            return NoContent();
        }

        #endregion
    }
}
