﻿namespace Globaltec_API.Models.Usuarios
{
    public class UsuarioOutput
    {
        public int Codigo { get; set; }
        public string Login { get; set; }
    }
}
