﻿namespace Globaltec_API.Entities
{
    public class Usuario
    {
        #region Propriedades

        public int Codigo { get; set; }

        public string Login { get; set; }

        public string Senha { get; set; }

        public int PessoaCodigo { get; set; }

        #endregion

        #region Construtor

        public Usuario(int codigo, string login, string senha, int pessoaCodigo)
        {
            Codigo = codigo;
            Login = login;
            Senha = senha;
            PessoaCodigo = pessoaCodigo;
        }

        #endregion

        #region Membros

        public void Update(string login, string senha)
        {
            Login = login;
            Senha = senha;
        }

        #endregion
    }
}
