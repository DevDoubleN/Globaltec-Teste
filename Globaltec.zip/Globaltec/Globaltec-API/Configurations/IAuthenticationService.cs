﻿using Globaltec_API.Models.Usuarios;

namespace Globaltec_API.Configurations
{
    public interface IAuthenticationService
    {
        string GerarToken(UsuarioOutput usuario);
    }
}
