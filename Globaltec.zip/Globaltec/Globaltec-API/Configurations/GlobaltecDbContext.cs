﻿using Globaltec_API.Entities;

namespace Globaltec_API.Configurations
{
    public class GlobaltecDbContext
    {
        public GlobaltecDbContext()
        {
            Pessoas = new List<Pessoa>();
            Pessoas.Add(new Pessoa(1, "Maria", "423.918.450 - 90", "GO", new DateTime(1999, 06, 25)));
            Usuarios = new List<Usuario>();
            Usuarios.Add(new Usuario(1, "admin", "admin", 1));
        }

        public List<Pessoa> Pessoas { get; set; }

        public List<Usuario> Usuarios { get; set; }
    }
}
