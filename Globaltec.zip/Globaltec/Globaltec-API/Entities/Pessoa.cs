﻿namespace Globaltec_API.Entities
{
    public class Pessoa
    {
        #region Propriedades

        public int Codigo { get; set; }

        public string Nome { get; set; }

        public string Cpf { get; set; }

        public string Uf { get; set; }

        public DateTime DataNascimento { get; set; }

        #endregion

        #region Construtor

        public Pessoa(int codigo, string nome, string cpf, string uf, DateTime dataNascimento)
        {
            Codigo = codigo;
            Nome = nome;
            Cpf = cpf;
            Uf = uf;
            DataNascimento = dataNascimento;
        }

        #endregion

        #region Membros

        public void Update(int codigo, string nome, string cpf, string uf, DateTime dataNascimento)
        {
            Codigo = codigo;
            Nome = nome;
            Cpf = cpf;
            Uf = uf;
            DataNascimento = dataNascimento;
        }

        #endregion

    }
}
