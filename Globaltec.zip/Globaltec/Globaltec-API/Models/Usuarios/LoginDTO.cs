﻿namespace Globaltec_API.Models.Usuarios
{
    public class LoginDTO
    {
        public string Login { get; set; }
        public string Senha { get; set; }
    }
}
