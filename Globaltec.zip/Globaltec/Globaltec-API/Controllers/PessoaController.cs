﻿using Globaltec_API.Configurations;
using Globaltec_API.Entities;
using Globaltec_API.Models.Pessoas;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Globaltec_API.Controllers
{
    [Route("/api/Pessoa")]
    [ApiController]
    [Authorize]
    public class PessoaController : ControllerBase
    {
        #region Membros

        private readonly GlobaltecDbContext _globaltecDbContext;

        #endregion

        #region Construtor

        public PessoaController(GlobaltecDbContext globaltecDbContext)
        {
            _globaltecDbContext = globaltecDbContext;
        }

        #endregion

        #region Actions

        /// <summary>
        /// Buscar uma lista completa de Pessoas cadastradas.
        /// </summary>
        /// <returns>Lista de Pessoas.</returns>
        /// <response code="200">Sucesso!</response>
        /// <response code="401">Não Autorizado!</response>
        [HttpGet("List")]
        public IActionResult GetAll()
        {
            var pessoas = _globaltecDbContext.Pessoas;

            return Ok(pessoas);
        }

        /// <summary>
        /// Busca o cadastro de uma Pessoa de acordo com o seu Código
        /// </summary>
        /// <param name="id">Código da Pessoa</param>
        /// <returns>Cadastro da Pessoa</returns>
        /// <response code="200">Sucesso!</response>
        /// <response code="401">Não Autorizado!</response>
        /// <response code="404">Não Encontrado!</response>
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var pessoa = _globaltecDbContext.Pessoas.FirstOrDefault(p => p.Codigo == id);
            if (pessoa == null)
                return NotFound();

            return Ok(pessoa);
        }

        /// <summary>
        /// Buscar uma lista de Pessoas de acordo com a UF cadastrada.
        /// </summary>
        /// <param name="codigo">UF de cadastro da Pessoa</param>
        /// <returns>Lista de Pessoas de acordo com a UF do cadastro semelhantes ao parâmetro informado.</returns>
        /// <response code="200">Sucesso!</response>
        /// <response code="401">Não Autorizado!</response>
        /// <response code="404">Não Encontrado!</response>
        [HttpGet("Find/{uf}")]
        public IActionResult GetByUf(string uf)
        {
            List<Pessoa> pessoas = _globaltecDbContext.Pessoas.Where(p => p.Uf == uf).ToList();

            if (pessoas.Count() <= 0)
                return NotFound();

            return Ok(pessoas);
        }

        /// <summary>
        /// Cadastrar uma nova Pessoa.
        /// </summary>
        /// <param name="pessoaDTO">Dados da Pessoa</param>
        /// <returns>Cadastro criado.</returns>
        /// <response code="201">Sucesso</response>
        /// <response code="401">Não Autorizado!</response>
        /// <response code="500">Falha na requisição!</response>
        [HttpPost("New")]
        public IActionResult Post(PessoaDTO pessoaDTO)
        {
            if (pessoaDTO == null)
                throw new Exception("Cadastro vazio!");

            var getPessoa = _globaltecDbContext.Pessoas.OrderByDescending(p => p.Codigo).Take(1).FirstOrDefault();

            ValidaCadastro(pessoaDTO);

            var pessoa = new Pessoa(
                getPessoa == null ? 1 : getPessoa.Codigo + 1,
                pessoaDTO.Nome,
                pessoaDTO.Cpf,
                pessoaDTO.Uf,
                pessoaDTO.DataNascimento
                );

            _globaltecDbContext.Pessoas.Add(pessoa);

            return CreatedAtAction("GetById", new { id = pessoa.Codigo }, pessoa);
        }

        /// <summary>
        /// Atualizar o cadastro de uma Pessoa.
        /// </summary>
        /// <param name="id">Identificador da Pessoa</param>
        /// <param name="pessoaDTO">Novos dados para o cadastro selecionado.</param>
        /// <returns>Cadastro atualizado</returns>
        /// <response code="200">Sucesso!</response>
        /// <response code="401">Não Autorizado!</response>
        /// <response code="404">Não Encontrado!</response>
        /// <response code="500">Falha na requisição!</response>
        [HttpPut("Update/{id}")]
        public IActionResult Put(int id, PessoaDTO pessoaDTO)
        {
            var pessoa = _globaltecDbContext.Pessoas.SingleOrDefault(p => p.Codigo == id);
            if (pessoa == null)
                return NotFound();

            ValidaCadastro(pessoaDTO);

            pessoa.Update(pessoa.Codigo, pessoaDTO.Nome, pessoaDTO.Cpf, pessoaDTO.Uf, pessoaDTO.DataNascimento);

            return Ok(pessoa);
        }

        /// <summary>
        /// Excluir um cadastro pelo seu Identificador.
        /// </summary>
        /// <param name="id">Identificador da Pessoa.</param>
        /// <returns>Sucesso ao excluir um cadastro de Pessoa.</returns>
        /// <response code="200">Sucesso!</response>
        /// <response code="401">Não Autorizado!</response>
        /// <response code="404">Não Encontrado!</response>
        /// <response code="500">Falha na requisição!</response>
        [HttpDelete("Delete/{id}")]
        public IActionResult Delete(int id)
        {
            var pessoa = _globaltecDbContext.Pessoas.FirstOrDefault(p => p.Codigo == id);
            if (pessoa == null)
                return NotFound();

            _globaltecDbContext.Pessoas.Remove(pessoa);

            return Ok();
        }

        #endregion

        #region Métodos Privados

        private void ValidaCadastro(PessoaDTO pessoaDTO)
        {
            string errors = string.Empty;

            if (string.IsNullOrWhiteSpace(pessoaDTO.Nome))
                errors = "O Nome da Pessoa não pode ser nulo! \n";
            else if (pessoaDTO.Nome.Length > 80)
                errors += "O tamanho máximo para o Nome é 80 caractéres! \n";
            if (pessoaDTO.Cpf.Length > 14)
                errors += "O tamanho máximo para o CPF é 14 caractéres! \n";
            if (pessoaDTO.Uf.Length > 2)
                errors += "O tamanho máximo para a Unidade Federativa é 2 caractéres.";

            if (errors != null)
                throw new Exception(errors);
        }

        #endregion
    }
}
